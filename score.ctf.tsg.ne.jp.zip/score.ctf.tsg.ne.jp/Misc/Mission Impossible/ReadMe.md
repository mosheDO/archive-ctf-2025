Name: Mission: Impossible
Value: 0
Description: The security system of CIA vault room is state-of-the-art.
There are a large number of pressure-sensitive, temperature-sensitive and audio-sensitive sensors.
And the terminal is operated by voice recognition.

http://35.194.98.181:57860/

---

CIAの金庫室のセキュリティシステムは最先端だ。
そこには大量の圧力センサー、温度センサー、そして音センサーが張り巡らされている。
そして端末は音声認識で動作する。

http://35.194.98.181:57860/
