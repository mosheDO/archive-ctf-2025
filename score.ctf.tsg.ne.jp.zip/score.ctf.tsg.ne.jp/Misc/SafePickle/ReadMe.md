Name: SafePickle
Value: 0
Description: I heard pickle can be exploited by reduce, so I disabled reduce!

> nc 35.194.98.181 53117

---

pickleはreduceを使って攻撃できると聞いたからreduceを無効化したよ！

> nc 35.194.98.181 53117

