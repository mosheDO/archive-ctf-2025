Name: ro_shellbox
Value: 0
Description: It should be safe since it’s read-only.

>  nc  35.194.98.181 42324 -q 5

---

read-onlyなら安全なはずです

>  nc  35.194.98.181 42324 -q 5
