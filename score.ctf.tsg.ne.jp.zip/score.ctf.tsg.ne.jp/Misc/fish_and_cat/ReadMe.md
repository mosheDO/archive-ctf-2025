Name: fish_and_cat
Value: 0
Description: Do you know the esolang fish (><>)? It’s pretty fun, so try writing something in it!

> nc 35.194.98.181 49873
---

fish(><>)という難解言語を知っていますか？面白いので、ぜひ書いてみてください！

> nc 35.194.98.181 49873
