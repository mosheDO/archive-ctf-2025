Name: Survey
Value: 0
Description: We have released a "Survey" to investigate the level of satisfaction of everyone who participated in the TSG CTF. 

Please let us know your honest impressions about TSG CTF. 

Teams that respond to the survey will receive a 1pt bonus! 

The time recorded when you solve this Survey is not used to determine your ranking.

https://forms.gle/FSBuEqxi91LWbSmu8

---

みなさんがTSG CTFに参加した満足度を調査するための「Survey」を公開しました。

TSG CTFに対するみなさんの素直な感想をお知らせください。

Surveyに回答していただいたチームにはボーナスの1ptを付与します！

surveyを解いた時間は、順位の判定に利用されません。

https://forms.gle/AdXfc9juz5y6L6JM7

