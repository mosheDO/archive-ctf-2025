Name: closed_ended
Value: 0
Description: We're all gonna get close()-ed.

> nc 34.84.25.24 50037

---

おれたちはみんなclose()される運命なんだ。

> nc 34.84.25.24 50037
