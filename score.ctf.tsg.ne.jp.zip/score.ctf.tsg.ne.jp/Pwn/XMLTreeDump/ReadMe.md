Name: XMLTreeDump
Value: 0
Description: I wrote an XML-dumping program. Hopefully it’s bug-free.

>  nc 34.84.25.24 36336 -q 5

---

XMLをダンプするプログラムを書きました。バグがないといいのですが。

>  nc 34.84.25.24 36336 -q 5
