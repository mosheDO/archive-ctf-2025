Name: global writer
Value: 0
Description: Just make 'em all global. Way easier.

> nc 34.84.25.24 58554

For beginners:
* First of all, download the attachments and see the source file.
* The goal of this challenge is to execute `/bin/sh` within the program running on the remote server. Once successful, find and read the flag file stored on the server.
* You can find plenty of information on attack methods by searching online. Let’s try out a few different ones.

---

全部グローバルにしたらラクじゃんね

> nc 34.84.25.24 58554

初心者向けヒント:
* まず、添付ファイルをダウンロードしてソースコードを見てください。
* この問題の目標は、リモートサーバー上で動いているプログラムの中で`/bin/sh`を実行することです。実行できたら、サーバーにフラグファイルがあるので、それを読んでください。
* 攻撃手法は検索するとたくさん情報が出てきます。いろいろ試してみましょう。
