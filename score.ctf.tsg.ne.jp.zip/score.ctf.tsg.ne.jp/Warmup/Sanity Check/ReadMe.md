Name: Sanity Check
Value: 0
Description: 
Log in to our [Discord server for TSG CTF](https://discord.gg/xJn7v62) and find the flag in the #readme channel. 
---


[TSG CTF のDiscordサーバー](https://discord.gg/xJn7v62)にログインして #readme チャンネルに書いてあるフラグを送信してください。
