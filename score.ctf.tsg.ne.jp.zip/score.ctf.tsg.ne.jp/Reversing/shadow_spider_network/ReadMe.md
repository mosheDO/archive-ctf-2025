Name: shadow_spider_network
Value: 0
Description: Something feels off

**Please verify that the flag is correct by entering it into the program before submitting it.**

---

不穏な感じだ。

**flagが正しいかどうかプログラムに入力して確認してから提出してください**
