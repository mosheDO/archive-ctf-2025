Name: medicine
Value: 0
Description: > I feel ill...

Hints for beginners:

- The attached file is an ELF executable for x86-64 Linux.
- Running it and entering the correct FLAG will display `Correct :)` and the flag.
- Segmentation fault may occur if the FLAG is incorrect.
- Use tools like Ghidra or IDA Free to get an overview of the process.
- Use gdb to observe its behavior while running.
- You don’t need to fully understand every single process.
  - Sometimes, it’s enough to identify the inputs and outputs.
---

> I feel ill...

- 添付ファイルはx86-64のLinux上で動くELF形式の実行可能ファイルです
- 実行して正しいFLAGを入力すると、`Correct :)`と入力したFLAGが表示されます
- 間違ったFLAGを入力するとセグメンテーションフォルトが起きる場合があります
- GhidraやIDA Freeで処理の概要を把握しましょう
- gdbで実際に動かしながら挙動を確認しましょう
- すべての処理の内容を正確に理解する必要はありません
  - その処理が何を入力とし、何を変更するのかを把握するだけで十分なこともあります
