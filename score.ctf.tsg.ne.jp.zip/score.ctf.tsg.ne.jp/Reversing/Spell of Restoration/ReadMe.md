Name: Spell of Restoration
Value: 0
Description: Did you write down the flag on your memo properly?

---

ちゃんとメモ用紙にフラグを書き留めていたかな?
