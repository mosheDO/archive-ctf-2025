Name: roundtrip
Value: 0
Description: When will the proposal reach stage 4?

http://35.221.67.248:5873

---

いつになったら stage 4 になるんですか?

http://35.221.67.248:5873


