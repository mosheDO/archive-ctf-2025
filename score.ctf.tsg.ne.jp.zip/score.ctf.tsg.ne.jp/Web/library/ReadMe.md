Name: library
Value: 0
Description: Our library's new staff portal is up! Only the head librarian can access the restricted archives.

http://35.221.67.248:10501

---

図書館のスタッフポータルができました！禁書庫にアクセスできるのは司書長だけです。

http://35.221.67.248:10501
