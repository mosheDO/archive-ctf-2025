Name: image-compress-revenge
Value: 0
Description: I tried making an app with Vibe coding. It's easy and nice, isn't it?

http://35.221.67.248:10502

---

Vibe coding でアプリケーションを作ってみました。楽でいいですねこれ

http://35.221.67.248:10502
