Name: bingo
Value: 0
Description: Trying things at random and hitting bingo might be about as difficult as getting a dog to find treasure.

> nc 35.194.98.181 10961

---

あてもなく試して当たりを引くのは、犬にお宝を見つけてもらうくらい難しいかもしれない。

> nc 35.194.98.181 10961

