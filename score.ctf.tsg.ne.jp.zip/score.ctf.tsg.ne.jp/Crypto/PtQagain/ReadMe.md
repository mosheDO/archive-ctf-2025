Name: PtQagain
Value: 0
Description: I’ll give you `p + q` encrypted twice with the same scheme! It’s the same thing anyway, so no problem... right?

Hints for beginners:

- The result of running `problem.py` is stored in `output.txt`.
- When you read `problem.py`, you can see that it encrypts the value `FLAG` and outputs it. Also, there are some other suspicious data in the output. Since the real value of `FLAG` is hidden, let's find it out from `problem.py` and its output!
- The original `FLAG` is a string (more precisely, a byte string), but to encrypt it, it is converted to the corresponding integer `m`  with the code `m = bytes_to_long(FLAG)`. If you get `m`, then you can obtain the `FLAG` with the code `long_to_bytes(m)`.

---


`p + q` を同じ暗号化で 2 回教えてあげるよ！どうせおんなじだし、問題ない...よね？

初心者向けのヒント:

- `problem.py` の実行結果が `output.txt` に保存されています。
- `problem.py` を読んでみると、 `FLAG` という値を暗号化して出力していることがわかります。また、他にも何やら怪しいデータが出力されています。本物の `FLAG` の値は隠されているため、 `problem.py` とその出力から、 `FLAG` の中身を突き止めてやりましょう！
- `FLAG` は文字列（正確にはバイト列）ですが、暗号化するために `m = bytes_to_long(FLAG)` というコードで対応する整数に変換しています。この `m` を求めることができれば、 `long_to_bytes(FLAG)` というコードでもとの `FLAG` を得ることができます。
