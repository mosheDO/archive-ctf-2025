Name: The Strongest Exponent I Thought
Value: 0
Description: > My original ultra mega super-duper ultimate strongest exponent!

Hints for beginners:

- The result of running `problem.py` is stored in `output.txt`.
- When you read `problem.py`, you can see that it encrypts the value `flag` and outputs it. Since the real value of `flag` is hidden, let's find it out from `problem.py` and its output!
- The original `flag` is a string, but to encrypt it, it is converted to the corresponding integer `m` with the code `m = int.from_bytes(flag, 'big')`. If you get `m`, then you can obtain the `flag` with the code `m.to_bytes((m.bit_length()-1)//8 + 1, 'big')`.

---

> ぼくのかんがえたさいきょうの 𝒆𝒙𝒑𝒐𝒏𝒆𝒏𝒕

初心者向けのヒント:

- `problem.py` の実行結果が `output.txt` に保存されています。
- `problem.py` を読んでみると、 `flag` という値を暗号化して出力していることがわかります。本物の `flag` の値は隠されているため、 `problem.py` とその出力から、 `flag` の中身を突き止めてやりましょう！
- `flag` は文字列ですが、暗号化するために `m = int.from_bytes(flag, 'big')` というコードで対応する整数に変換しています。この `m` を求めることができれば、 `m.to_bytes((m.bit_length()-1)//8 + 1, 'big')` というコードでもとの `flag` を得ることができます。
